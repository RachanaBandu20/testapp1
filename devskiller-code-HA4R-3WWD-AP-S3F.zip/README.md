# Search-Engine Application with React.js 

## Introduction

You are implementing search/filter functionalities for an online shop application for your client. A colleague of yours has already implemented some of the functionalities requested by the client, but he is currently on holidays. You have to help finish the remaining functionalities, so the team meets the deadline.

The missing functionalities include:
* Checkbox fields that allow users to display or hide specific columns in the table of products.
* Filter fields that allow users to set a range on the items prices.
* If the user provides only the starting price, the product price should be inside the [startPrice, infinity] interval. However, if the user provides the ending price only, the interval should be [0, endPrice].
* Users should be able to see the filtered or searched products in a table.

## Problem Statement

Your task is to:

* Import products from the `products.json` inside /src/assets/ folder, which will be used for the search/filter functionalities.
* Put the imported data in the `products` array in the Search.js component.
* Implement the toggle functionality by adding a handler to the checkbox change in the ToggleColumns.js.
* Pass a column object to the ProductList and reflect the change in the checkbox appropriately (by displaying or hiding the column).
* Pass the filtered products to the ProductList.js component, so they get displayed in the table.
* Show each item from the passed prop in the table inside the ProductList.js component.
* Pass the `priceFrom` and the `priceTo` attributes to the FilterForm.js component as props.
* Implement the change input and submit the form handlers to the FilterForm.js component.
* Change the filtered products that are displayed in the ProductList.js, so that it only contains the products with a price within the specified range.


For more details, please run the task on the Devskiller platform and see the failing tests.

## Setup
1. Use `npm install` to get dependencies.
2. Start the app with `npm run start` and point the web browser to `http://localhost:8080/`.
3. Use `npm run test` to see the failing tests.
4. Fix any issues, so that all tests pass.
5. Solve all issues mentioned here.
6. Submit your code on the Devskiller platform to check if the task is completed.

## Good Luck!
